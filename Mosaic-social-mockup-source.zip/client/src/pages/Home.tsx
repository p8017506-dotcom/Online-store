import { useMemo, useState } from "react";
import { toggleLikeState } from "@/lib/social";
import {
  Bell,
  Bookmark,
  Compass,
  Heart,
  Home as HomeIcon,
  MessageCircle,
  MoreHorizontal,
  Plus,
  Search,
  Send,
  Settings2,
  Sparkles,
  UserRound,
} from "lucide-react";

type Post = {
  id: number;
  name: string;
  handle: string;
  avatar: string;
  image: string;
  location: string;
  caption: string;
  likes: number;
  comments: number;
  time: string;
  liked: boolean;
};

const stories = [
  { name: "Your story", image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=160&q=80", own: true },
  { name: "Mina", image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=160&q=80" },
  { name: "Noah", image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=160&q=80" },
  { name: "Aya", image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=160&q=80" },
  { name: "Theo", image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=160&q=80" },
  { name: "Lena", image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=160&q=80" },
];

const initialPosts: Post[] = [
  {
    id: 1,
    name: "Mina Park",
    handle: "minapark",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80",
    image: "https://images.unsplash.com/photo-1518005020951-eccb494ad742?auto=format&fit=crop&w=1200&q=88",
    location: "Palm Springs, California",
    caption: "A little color therapy for the middle of the week.",
    likes: 248,
    comments: 18,
    time: "42 MIN AGO",
    liked: false,
  },
  {
    id: 2,
    name: "Studio Noma",
    handle: "studionoma",
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=120&q=80",
    image: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=1200&q=88",
    location: "Copenhagen, Denmark",
    caption: "Quiet corners, considered materials, and room to breathe.",
    likes: 531,
    comments: 32,
    time: "3 HRS AGO",
    liked: true,
  },
];

const suggested = [
  { name: "Alba Studio", handle: "alba.studio", image: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=120&q=80" },
  { name: "Jon Bell", handle: "jonbell.photo", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80" },
  { name: "The Green Edit", handle: "thegreenedit", image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80" },
];

function Avatar({ src, size = "md", ring = false }: { src: string; size?: "sm" | "md" | "lg"; ring?: boolean }) {
  return (
    <div className={`${ring ? "avatar-ring" : ""} avatar avatar-${size}`}>
      <img src={src} alt="" />
    </div>
  );
}

function NavItem({ icon: Icon, label, active = false, onClick }: { icon: typeof HomeIcon; label: string; active?: boolean; onClick?: () => void }) {
  return (
    <button className={`nav-item ${active ? "nav-item-active" : ""}`} onClick={onClick} aria-label={label}>
      <Icon size={active ? 21 : 20} strokeWidth={active ? 2.4 : 1.8} />
      <span>{label}</span>
    </button>
  );
}

function ProfileSurface({ posts }: { posts: Post[] }) {
  return (
    <section className="profile-page">
      <div className="profile-page-heading"><p className="eyebrow">YOUR SPACE</p><button className="icon-button" aria-label="Profile settings"><Settings2 size={19} /></button></div>
      <div className="profile-hero"><Avatar src={stories[0].image} size="lg" /><div className="profile-hero-copy"><h1>Alex Morgan</h1><p className="profile-handle">@alexmorgan</p><p className="profile-bio">Collecting quiet details, bright corners, and everyday wonder.<br />Based between the city and the sea.</p></div></div>
      <div className="profile-stats"><div><strong>48</strong><span>Posts</span></div><div><strong>1.8k</strong><span>Followers</span></div><div><strong>312</strong><span>Following</span></div></div>
      <div className="profile-tabs"><button className="profile-tab-active"><Compass size={16} /> Grid</button><button><Bookmark size={16} /> Saved</button></div>
      <div className="profile-grid">{[...posts, ...posts, ...posts].map((post, index) => <button className="profile-tile" key={`${post.id}-${index}`} aria-label={`Open post ${index + 1}`}><img src={post.image} alt="" /></button>)}</div>
    </section>
  );
}

export default function Home() {
  const [posts, setPosts] = useState(initialPosts);
  const [activeTab, setActiveTab] = useState("Home");
  const [search, setSearch] = useState("");
  const [saved, setSaved] = useState<number[]>([]);

  const filteredPosts = useMemo(() => {
    if (!search.trim()) return posts;
    const term = search.toLowerCase();
    return posts.filter((post) => `${post.name} ${post.handle} ${post.caption}`.toLowerCase().includes(term));
  }, [posts, search]);

  const toggleLike = (id: number) => {
    setPosts((current) => current.map((post) => post.id === id ? { ...post, ...toggleLikeState(post) } : post));
  };

  const toggleSave = (id: number) => {
    setSaved((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  };

  return (
    <div className="social-app">
      <aside className="desktop-sidebar">
        <div className="brand-lockup"><div className="brand-mark"><Sparkles size={17} /></div><span>mosaic</span></div>
        <div className="sidebar-nav">
          <NavItem icon={HomeIcon} label="Home" active={activeTab === "Home"} onClick={() => setActiveTab("Home")} />
          <NavItem icon={Search} label="Search" active={activeTab === "Search"} onClick={() => setActiveTab("Search")} />
          <NavItem icon={Compass} label="Discover" active={activeTab === "Discover"} onClick={() => setActiveTab("Discover")} />
          <NavItem icon={MessageCircle} label="Messages" active={activeTab === "Messages"} onClick={() => setActiveTab("Messages")} />
          <NavItem icon={Bell} label="Activity" active={activeTab === "Activity"} onClick={() => setActiveTab("Activity")} />
          <NavItem icon={Bookmark} label="Saved" active={activeTab === "Saved"} onClick={() => setActiveTab("Saved")} />
        </div>
        <button className="create-button"><Plus size={18} /> Create post</button>
        <div className="sidebar-bottom"><NavItem icon={Settings2} label="Settings" /><NavItem icon={UserRound} label="Profile" active={activeTab === "Profile"} onClick={() => setActiveTab("Profile")} /></div>
      </aside>

      <header className="mobile-header"><div className="brand-lockup"><div className="brand-mark"><Sparkles size={15} /></div><span>mosaic</span></div><div className="mobile-header-actions"><button aria-label="Activity"><Bell size={20} /></button><Avatar src={stories[0].image} size="sm" /></div></header>

      <main className="feed-column">
        {activeTab === "Profile" ? <ProfileSurface posts={posts} /> : <>
        <div className="feed-topbar"><div><p className="eyebrow">TUESDAY, APRIL 16</p><h1>Your daily mosaic</h1></div><button className="topbar-action" aria-label="Messages"><Send size={19} /></button></div>
        <div className="search-wrap"><Search size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search people, places, or ideas" aria-label="Search posts" /></div>

        <section className="stories-panel" aria-label="Stories">
          <div className="section-heading"><h2>Stories</h2><button>View all</button></div>
          <div className="stories-row">{stories.map((story) => <button className="story" key={story.name}><div className={`story-image ${story.own ? "story-own" : ""}`}><Avatar src={story.image} size="md" ring={!story.own} />{story.own && <span className="story-add"><Plus size={11} /></span>}</div><span>{story.name}</span></button>)}</div>
        </section>

        <div className="feed-heading"><div><p className="eyebrow">CURATED FOR YOU</p><h2>Fresh from your circle</h2></div><button className="filter-button"><Sparkles size={15} /> For you</button></div>

        <div className="posts-list">{filteredPosts.map((post) => <article className="post-card" key={post.id}>
          <div className="post-header"><div className="post-author"><Avatar src={post.avatar} size="md" /><div><strong>{post.name}</strong><span>{post.location}</span></div></div><button className="icon-button" aria-label="More post options"><MoreHorizontal size={20} /></button></div>
          <div className="post-image-wrap"><img className="post-image" src={post.image} alt={`${post.name} post`} /><button className={`image-like ${post.liked ? "image-like-active" : ""}`} onClick={() => toggleLike(post.id)} aria-label={post.liked ? "Unlike post" : "Like post"}><Heart size={26} fill={post.liked ? "currentColor" : "none"} /></button></div>
          <div className="post-actions"><div className="action-group"><button className={post.liked ? "liked" : ""} onClick={() => toggleLike(post.id)} aria-label={post.liked ? "Unlike post" : "Like post"}><Heart size={21} fill={post.liked ? "currentColor" : "none"} /></button><button aria-label="Comment"><MessageCircle size={21} /></button><button aria-label="Share"><Send size={20} /></button></div><button className={saved.includes(post.id) ? "saved" : ""} onClick={() => toggleSave(post.id)} aria-label={saved.includes(post.id) ? "Remove from saved" : "Save post"}><Bookmark size={21} fill={saved.includes(post.id) ? "currentColor" : "none"} /></button></div>
          <div className="post-copy"><strong>{post.likes.toLocaleString()} likes</strong><p><b>{post.handle}</b> {post.caption}</p><button className="comments-link">View all {post.comments} comments</button><span className="post-time">{post.time}</span></div>
        </article>)}</div>
        {filteredPosts.length === 0 && <div className="empty-state"><Search size={28} /><h3>No posts found</h3><p>Try a different search term.</p></div>}
        </>}
      </main>

      <aside className="right-rail">
        <div className="profile-summary"><Avatar src={stories[0].image} size="lg" /><div><strong>Alex Morgan</strong><span>@alexmorgan</span></div><button>Edit</button></div>
        <div className="rail-section"><div className="rail-heading"><span>Suggested for you</span><button>See all</button></div>{suggested.map((person) => <div className="suggested-person" key={person.handle}><Avatar src={person.image} size="sm" /><div><strong>{person.name}</strong><span>{person.handle}</span></div><button>Follow</button></div>)}</div>
        <div className="rail-note"><div className="note-icon"><Sparkles size={16} /></div><div><strong>Make space for wonder</strong><p>Follow ideas that make your day feel a little more yours.</p></div></div>
        <p className="footer-note">About · Help · Privacy · Terms<br />© 2024 MOSAIC</p>
      </aside>

      <nav className="mobile-nav"><NavItem icon={HomeIcon} label="Home" active={activeTab === "Home"} onClick={() => setActiveTab("Home")} /><NavItem icon={Compass} label="Discover" active={activeTab === "Discover"} onClick={() => setActiveTab("Discover")} /><button className="mobile-create" aria-label="Create post"><Plus size={21} /></button><NavItem icon={Heart} label="Activity" active={activeTab === "Activity"} onClick={() => setActiveTab("Activity")} /><NavItem icon={UserRound} label="Profile" active={activeTab === "Profile"} onClick={() => setActiveTab("Profile")} /></nav>
    </div>
  );
}
