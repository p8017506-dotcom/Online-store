import { describe, expect, it } from "vitest";
import { toggleLikeState } from "./social";

describe("toggleLikeState", () => {
  it("likes a post and increments its count", () => {
    expect(toggleLikeState({ liked: false, likes: 12 })).toEqual({ liked: true, likes: 13 });
  });

  it("unlikes a post and never drops below zero", () => {
    expect(toggleLikeState({ liked: true, likes: 1 })).toEqual({ liked: false, likes: 0 });
    expect(toggleLikeState({ liked: true, likes: 0 })).toEqual({ liked: false, likes: 0 });
  });
});
