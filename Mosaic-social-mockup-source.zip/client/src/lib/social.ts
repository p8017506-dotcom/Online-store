export type LikeState = {
  liked: boolean;
  likes: number;
};

export function toggleLikeState(state: LikeState): LikeState {
  return {
    liked: !state.liked,
    likes: state.liked ? Math.max(0, state.likes - 1) : state.likes + 1,
  };
}
